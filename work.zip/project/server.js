import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import sqlite3 from 'sqlite3';
import { body, validationResult } from 'express-validator';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Initialize Express app
const app = express();
const port = 2000;

// Initialize SQLite database
const db = new sqlite3.Database('users.db');

// Create users table if it doesn't exist
db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);
});

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Validation middleware
const validateUser = [
    body('name').trim().isLength({ min: 2 }).escape(),
    body('email').trim().isEmail().normalizeEmail()
];

// Routes
app.get('/', (req, res) => {
    res.sendFile(join(__dirname, 'public', 'index.html'));
});

// Create user
app.post('/api/users', validateUser, (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { name, email } = req.body;
    db.run(
        'INSERT INTO users (name, email) VALUES (?, ?)',
        [name, email],
        function(err) {
            if (err) {
                if (err.code === 'SQLITE_CONSTRAINT') {
                    res.status(400).json({ error: 'Email already exists' });
                } else {
                    res.status(500).json({ error: 'Server error' });
                }
                return;
            }
            res.status(201).json({ id: this.lastID });
        }
    );
});

// Read all users
app.get('/api/users', (req, res) => {
    db.all('SELECT * FROM users ORDER BY created_at DESC', [], (err, users) => {
        if (err) {
            res.status(500).json({ error: 'Server error' });
            return;
        }
        res.json(users);
    });
});

// Read single user
app.get('/api/users/:id', (req, res) => {
    db.get('SELECT * FROM users WHERE id = ?', [req.params.id], (err, user) => {
        if (err) {
            res.status(500).json({ error: 'Server error' });
            return;
        }
        if (!user) {
            res.status(404).json({ error: 'User not found' });
            return;
        }
        res.json(user);
    });
});

// Update user
app.put('/api/users/:id', validateUser, (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { name, email } = req.body;
    db.run(
        'UPDATE users SET name = ?, email = ? WHERE id = ?',
        [name, email, req.params.id],
        function(err) {
            if (err) {
                if (err.code === 'SQLITE_CONSTRAINT') {
                    res.status(400).json({ error: 'Email already exists' });
                } else {
                    res.status(500).json({ error: 'Server error' });
                }
                return;
            }
            if (this.changes === 0) {
                res.status(404).json({ error: 'User not found' });
                return;
            }
            res.json({ message: 'User updated' });
        }
    );
});

// Delete user
app.delete('/api/users/:id', (req, res) => {
    db.run(
        'DELETE FROM users WHERE id = ?',
        [req.params.id],
        function(err) {
            if (err) {
                res.status(500).json({ error: 'Server error' });
                return;
            }
            if (this.changes === 0) {
                res.status(404).json({ error: 'User not found' });
                return;
            }
            res.json({ message: 'User deleted' });
        }
    );
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});